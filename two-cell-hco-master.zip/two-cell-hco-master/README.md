# Two-Cell Half-Center Oscillator

### 1-spiking.hoc

### 2-adaptation.hoc

### 3-bursting.hoc

### 4-soma-synapse.hoc

### 5-hco-single-cell.hoc

### 6-hco-two-cell.hoc
